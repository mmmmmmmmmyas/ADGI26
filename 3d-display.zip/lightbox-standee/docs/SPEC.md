# Handoff: Lightbox Standee — Interactive 3D Viewer

## Overview
An interactive 3D model of a 4-legged standee carrying a lit lightbox with three stacked map layers (Creative City Ecosystem). Visitors orbit, zoom, and watch the map layers separate/compress with zoom. It sits on a pure-black void and is intended as a hero/feature module on the website.

## About this document
Exact spec of the current build. Source of truth for values is `src/app.js`; keep this file in sync when behaviour changes.

## Fidelity
**High-fidelity.** Final colors, dimensions, lighting, blend modes, zoom→gap mapping and default camera. Recreate exactly.

---

## Scene / View

### Viewport
- Full-bleed canvas, `position: fixed; inset: 0` in the prototype (in an embed: fill the container; recommended aspect ≥ 16:10, min-height 520px).
- Background `#000000`. No ground plane, no shadows, no hemisphere/ambient light.
- `touch-action: none` on the canvas.

### Units & axes
Meters, Y-up, model centred on origin. The deck tilts upward toward **+X**.

### Model hierarchy (names are used in GLB/OBJ export)
```
lightbox_standee (Group)
├─ wood_frame (Group)
│  └─ post_front / post_right / post_left / post_back   Box 0.08 × 1.20 × 0.08, centres (±0.4775, 0.60, ±0.735)
└─ deck (Group)  position (0, 0.88, 0), rotation.z = +6.5°
   ├─ rail_front / rail_back      Box 1.46 × 0.09 × 0.07, y = −0.045, z = ±0.66
   ├─ stop_{front|back}_{low|high} Box 0.035³, x = ±0.71, y = 0.0185, z = ±0.675
   ├─ surface_plane               Box 1.36 × 0.012 × 1.388, y = 0.007
   └─ lightbox (Group)            x = +0.0735, z = 0
      ├─ lightbox_body            Box 1.0545 × 0.09 × 1.23, y = 0.058
      ├─ lightbox_diffuser        Plane 1.0545 × 1.23 (facing +Y), y = 0.1042
      └─ screen_1 / screen_2      Box 1.0545 × 0.006 × 1.23 (+ edge outline)
```
- Lightbox X:Z = map image aspect (2127 : 2481) so the map is never cropped.
- Lightbox placement on surface: back (+X) gap = side gaps = **0.079 m**; front (−X) gap = **0.2265 m**.

### Materials
| Part | Spec |
|---|---|
| Frame + surface fill | `MeshBasicMaterial` #000, `transparent`, `opacity 0`, `depthWrite false` (invisible fill) |
| Frame + surface stroke | `EdgesGeometry(geo, 20°)` → `LineSegments`, `LineBasicMaterial` **#ECD6AE @ 50% opacity** (1 px — WebGL line width is fixed) |
| Lightbox body | `MeshStandardMaterial` #F3F1EC, roughness 0.7, emissive #FFF8EF × 0.12 |
| Lightbox diffuser | `MeshStandardMaterial` #141414, roughness 0.95, emissive #FFFFFF × 0.85, `emissiveMap` = face canvas (below) |
| Screen panes | `MeshStandardMaterial` #F4F6F8, roughness 0.15, **opacity 0.10**, `depthWrite false`, double-sided, renderOrder 5 |
| Screen edges | `LineBasicMaterial` #FFFFFF @ 55% |

### Lightbox face canvas (emissive map)
Canvas 1638 × 1904 px (x → box +X, y → box +Z). Scale factor `K = width / 512`.
1. Fill `#CFCBC3`.
2. Edge glow: rounded-rect stroke inset 46K, radius 30K, lineWidth 46K, `#FFFAF2`, `blur(22K)`.
3. Centre lift: rect inset 150K, `rgba(255,252,246,.22)`, `blur(40K)`.
4. **Layer 1 map, "plus darker"**: draw map rotated 90° (map top → +X / back end), fitted edge-to-edge onto white; per pixel `out = max(0, base + map − 255)` per channel.

### Pane prints (Layer 2 on screen_1, Layer 3 on screen_2)
- Plane 1.0545 × 1.23, 0.8 mm above each pane's top face, same 90° rotation/fit as Layer 1.
- **"Plus darker" in WebGL:** `ShaderMaterial`, `blendEquation = ReverseSubtract`, `blendSrc = One`, `blendDst = One`; fragment `gl_FragColor = vec4((1.0 - tex.rgb) * tex.a, 0.0)` → dst − (1 − src)·α. renderOrder 12 / 13, `depthWrite false`.
- Over black background this has no visible effect (expected — it only darkens the lit lightbox behind).

### Light beam (viewer-only, not exported)
- Additive (`One, One`) `ShaderMaterial` volume made of 46 horizontal + 30 + 34 vertical slices; height 1.35 m above the face, spreads 20% outward, edge softness `0.02 + 0.22·t`.
- Colour (1.0, 0.97, 0.92), gain 0.20, falloff `pow(1 − t, 1.5)`, halo term × 0.12. Static (no shimmer, no particles). Full shader in `app.js`.
- Point light #FFF4E8, intensity 0.4, distance 3, decay 2, 0.35 m above face centre.

### Lighting
Key directional ×1.9 (no shadow), other studio directionals ×0.22, rim directional #DFE6FF ×0.7 at (3, 4, −4). Hemisphere light hidden. Renderer: ACES/sRGB as in `three-d-stage.js`.

---

## Interactions & Behavior

### Camera
- OrbitControls: drag = orbit, wheel/pinch = zoom, right-drag = pan, damping on.
- **Default view:** position (−1.0998, 2.2303, −1.4091), target (0.0497, 0.8256, 0.0356) → reads **151%**.
- Zoom % = `3.5 / distance(camera, target) × 100`. Limits: minDistance 0.875 (400%), maxDistance 7.0 (50%).

### Zoom → pane gap
Gap between lightbox face → screen_1 → screen_2 (equal steps). Prints move with their panes.
| Zoom | Gap |
|---|---|
| ≤ 120% | 0.20 m (cap) |
| 120% – 220% | linear 0.20 → 0.02 m |
| ≥ 220% | 0.02 m (floor) |
Updated on every controls `change` event.

### Turntable rotation
- On at load, `autoRotateSpeed = 1.0` (≈ 1 turn/min). Slider 0.1 – 4.0, step 0.1.
- Pauses during drag (`start`), resumes on `end` if toggle is on.

### Loading
- "Loading…" centred (#E9E6DF @ 45%, 12.5px, letter-spacing .04em) until Layer 1–3 images are painted; then canvas + HUD fade in (opacity, 0.6s ease).
- Missing/broken CSV → built-in defaults; missing image → that layer skipped (console warning), page still loads.

---

## UI chrome

### Bottom HUD (centred, `bottom: 68px + safe-area`)
- Container: flex, gap 12px, padding 5px 12px 5px 5px, border 1px rgba(255,255,255,.14), radius 10px, bg rgba(255,255,255,.06), `backdrop-filter: blur(8px)`.
- Text: system UI stack, 500, 12.5px, line-height 1, #E9E6DF @ 75%, tabular numbers.
- **Rotate toggle** button: h 28px, padding 0 10px, radius 6px, border rgba(255,255,255,.14), bg rgba(255,255,255,.08), text #E9E6DF. Hover bg .14. Off state (`aria-pressed=false`): transparent bg, text @ 55%. Copy: `Rotate: On` / `Rotate: Off`.
- **Speed**: label "Speed", range 110px (72px ≤ 420px viewport), `accent-color #ECD6AE`, value `1.0×` (min-width 2.6em).
- 1×16px divider rgba(255,255,255,.14).
- **Zoom readout**: `Zoom 151%`.

### Download toolbar (bottom-right; centred ≤ 520px)
"Download OBJ + MTL" / "Download GLB" — bg rgba(255,255,255,.06), border .14, text #E9E6DF, hover .12. Hide with `show_downloads = 0`. The beam and pane prints are not exported.

### Hint note (bottom-left)
"Drag to orbit · scroll to zoom · right-drag to pan", #E9E6DF @ 36%. Hidden ≤ 1100px.

---

## State
| State | Type | Source / trigger |
|---|---|---|
| `rotating` | bool | `rotate_on` setting; toggle click |
| `rotateSpeed` | number 0.1–4 | `rotate_speed` setting; slider input |
| `zoomPct` | number | derived from camera distance on `change` |
| `paneGap` | meters | derived from `zoomPct` |
| `ready` | bool | all layer images painted |

## Content configuration (CSV)
`data/layers.csv` — `slot,file,label`: `face` (lightbox), `pane1` (centre pane), `pane2` (top pane). Empty `file` hides the layer.
`data/settings.csv` — `gap_max_cm 20`, `gap_min_cm 2`, `zoom_low_pct 120`, `zoom_high_pct 220`, `show_downloads 1`, `rotate_on 1`, `rotate_speed 1`.
In a native port these can become CMS fields / component props with the same names and defaults.

## Design Tokens
- Colors: void #000000 · stroke wood #ECD6AE (50%) · UI text #E9E6DF · UI border rgba(255,255,255,.14) · UI fill rgba(255,255,255,.06/.08/.12/.14) · lightbox shell #F3F1EC · emissive #FFF8EF · glow #FFFAF2 / #CFCBC3 · screen #F4F6F8 (10%) · rim light #DFE6FF · beam (255,247,235)
- Radius: 6px (buttons), 8px (toolbar), 10px (HUD)
- Type: system UI (-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif), 500, 12.5px / 11px (mobile toolbar)
- Motion: 0.6s ease fade-in; OrbitControls damping

## Assets
| File | Use | Notes |
|---|---|---|
| `assets/map-layer-1.webp` | Lightbox face (Layer 1) | 2400 px wide, compressed from client PNG (2481 × 2127) |
| `assets/map-layer-2.svg` | Centre pane (Layer 2) | 3307 × 2835, client-supplied |
| `assets/map-layer-3.svg` | Top pane (Layer 3) | 3307 × 2835, client-supplied |
| `favicon.svg` | Favicon | placeholder mark |

## Integration options
**A — iframe:** deploy this repo to Vercel, then embed on any site:
```html
<div style="position:relative;width:100%;aspect-ratio:16/10;min-height:520px;background:#000;border-radius:12px;overflow:hidden">
  <iframe src="https://YOUR-PROJECT.vercel.app" title="Lightbox standee 3D model"
          style="position:absolute;inset:0;width:100%;height:100%;border:0"
          loading="lazy" allow="fullscreen"></iframe>
</div>
```
The prototype's HUD is positioned for full-viewport; inside a short iframe it still fits (min-height 520px).

**B — native port:** recreate the scene from the specs above in the site's 3D layer; keep the `layers` / `settings` keys as props. Lazy-load three.js (≈ 600 KB) only when the module scrolls into view.

## Requirements / notes
- three.js **0.184.0** (pinned via import map with SRI in `index.html`).
- Must be served over http(s) — CSV fetch and canvas pixel reads fail on `file://`. Images must be same-origin (or CORS-enabled) for the "plus darker" pixel pass.
- WebGL required; `<noscript>` message provided.

## Files
```
  index.html            page shell, HUD markup + CSS, import map
  src/app.js            ALL model, material, shader, zoom, rotation logic
  src/three-d-stage.js  viewer shell (renderer, controls, export)
  data/layers.csv       layer → image mapping
  data/settings.csv     behaviour defaults
  assets/               map images
  vercel.json           headers / caching
  package.json          `npm run dev` local server
  README.md             workflow guide
  AGENTS.md             rules for AI coding assistants
  docs/SPEC.md          this file
```
