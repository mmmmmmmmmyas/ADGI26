Follow the rules in /AGENTS.md (code map, constraints, done checklist). Full spec: /docs/SPEC.md.
