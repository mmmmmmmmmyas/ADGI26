See AGENTS.md for project rules and the code map. Full spec: docs/SPEC.md.
