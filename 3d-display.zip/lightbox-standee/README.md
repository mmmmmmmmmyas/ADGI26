# Lightbox Standee — 3D web viewer

Interactive three.js model of the lightbox standee with 3 stacked map layers.
Static site — no build, no installs. **GitHub → VS Code → Vercel.**

---

## 1 · Upload to GitHub
1. github.com → **New repository** → name `lightbox-standee` → **Create** (leave README / .gitignore / license unticked).
2. Open VS Code → `Cmd/Ctrl + Shift + P` → **Git: Clone** → paste the repo URL → choose a folder → **Open**.
3. Unzip this package and copy **everything** into the cloned folder — including hidden items (`.gitignore`, `.vscode`, `.github`, `.cursorrules`). Mac: `Cmd + Shift + .` shows hidden files.
4. Source Control panel → message `Initial commit` → **Commit** → **Sync Changes**.

## 2 · Vibe code in VS Code
1. Accept the recommended extensions prompt (**Live Server**, **Rainbow CSV**, Copilot Chat).
2. Preview: right-click `index.html` → **Open with Live Server** (auto-reloads on save). Don't double-click the file.
3. Use your AI assistant (Copilot / Claude Code / Cursor). It auto-reads `AGENTS.md` / `CLAUDE.md` / `.github/copilot-instructions.md`, which tell it where everything lives and what not to break.
4. Example prompts:
   - "Make the wood stroke 70% opacity."
   - "Swap the top pane image for assets/new-layer.svg."
   - "Start the view at zoom 180%."
   - "Hide the download buttons on mobile."
5. No-code edits: open `data/layers.csv` or `data/settings.csv` and change values.
6. Commit + push when happy.

## 3 · Deploy with Vercel
1. vercel.com → sign in with GitHub → **Add New → Project** → **Import** `lightbox-standee`.
2. Framework Preset **Other** · Build Command **empty** · Output Directory `.` → **Deploy**.
3. Live at `https://<project>.vercel.app`. Every push to `main` redeploys (~30 s); other branches get preview URLs.
4. Custom domain: Project → **Settings → Domains**.

---

## Content settings
**data/layers.csv** — `slot,file,label`
- `face` = lightbox top · `pane1` = centre pane · `pane2` = top pane
- `file` = image path in the repo (PNG/JPG/WebP/SVG). Empty = hide layer.

**data/settings.csv** — `key,value`
| key | default | meaning |
|---|---|---|
| gap_max_cm | 20 | pane gap at/below zoom_low_pct |
| gap_min_cm | 2 | pane gap at/above zoom_high_pct |
| zoom_low_pct | 120 | zoom where panes start closing |
| zoom_high_pct | 220 | zoom where panes are fully closed |
| show_downloads | 1 | OBJ/GLB buttons (0 = hide) |
| rotate_on | 1 | turntable on at load (0 = off) |
| rotate_speed | 1 | 0.1–4 (1 ≈ one turn/min) |

## Embed on another website
```html
<div style="position:relative;width:100%;aspect-ratio:16/10;min-height:520px;background:#000;overflow:hidden">
  <iframe src="https://YOUR-PROJECT.vercel.app" title="Lightbox standee 3D model"
          style="position:absolute;inset:0;width:100%;height:100%;border:0" loading="lazy"></iframe>
</div>
```

## Structure
```
index.html            page + bottom bar
src/app.js            model, materials, beam, zoom, rotation
src/three-d-stage.js  renderer, orbit controls, export
data/                 CSV content + settings
assets/               map images
docs/SPEC.md          full design spec (every value)
AGENTS.md             AI-assistant rules (+ CLAUDE.md, .github/copilot-instructions.md, .cursorrules)
vercel.json           headers + caching
```

## Troubleshooting
- **Blank / stuck on "Loading…"** → opened via file:// — use Live Server.
- **Image missing** → path in `layers.csv` doesn't match the file (case-sensitive on Vercel).
- **CSV edit not showing** → hard refresh (`Cmd/Ctrl + Shift + R`).
