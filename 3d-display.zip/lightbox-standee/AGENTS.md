# AGENTS.md — rules for AI coding assistants

Project: interactive three.js viewer of a lightbox standee with 3 stacked map layers.
Static site, **no build step, no framework, no npm dependencies.** Deployed on Vercel from GitHub `main`.

## Map of the code
| Want to change… | Edit |
|---|---|
| Which image is on which layer | `data/layers.csv` |
| Pane gap, zoom thresholds, rotation defaults, download buttons | `data/settings.csv` |
| Model geometry / sizes (meters) | `src/app.js` → "dimensions" block |
| Colors, opacity, materials | `src/app.js` → "materials" block |
| Light beam look | `src/app.js` → beam `uniforms` + `fragmentShader` |
| Zoom → pane-gap logic | `src/app.js` → `showZoom` / `setGap` |
| Default camera view | `src/app.js` → `// Default view` |
| Rotation behaviour | `src/app.js` → `// Turntable rotation` |
| Bottom bar (HUD) markup + style | `index.html` (`#hud`) |
| Renderer, orbit controls, export buttons | `src/three-d-stage.js` (avoid editing unless necessary) |
| Full design spec (every value) | `docs/SPEC.md` |

## Rules
- Keep it static: plain ES modules, no bundler, no React, no `npm install` requirements.
- three.js is pinned to **0.184.0** via the import map in `index.html` with SRI hashes. If you change the version, update every URL **and** remove/replace the `integrity` block, or the page will fail to load.
- Units are meters, Y-up. The deck tilts +6.5° toward +X.
- Layer images are drawn rotated 90° (image top → back/+X end) and fitted edge-to-edge. Lightbox X:Z = Layer 1 aspect (2127:2481) — if Layer 1's aspect changes, update `MAP_W`/`MAP_H`.
- "Plus darker" blend: Layer 1 = per-pixel `max(0, a + b − 255)` on canvas; Layers 2–3 = WebGL `ReverseSubtract` with `(1 − rgb)·a`. Don't swap for CSS blend modes (they don't apply inside WebGL).
- Images must be same-origin (canvas pixel reads).
- Keep `data/*.csv` comma-free inside values (or quote them).
- After changing behaviour, update `docs/SPEC.md`.
- Test locally with Live Server or `npm run dev` — never via file://.

## Done checklist
1. Page loads, "Loading…" disappears, no console errors.
2. Zoom readout changes; panes close between zoom_low and zoom_high.
3. Rotate toggle + speed slider work; drag pauses rotation, release resumes.
4. Nothing overlaps at ~375px, ~900px and desktop widths.
